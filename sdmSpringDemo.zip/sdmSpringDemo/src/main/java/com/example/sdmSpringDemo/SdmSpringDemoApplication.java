package com.example.sdmSpringDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SdmSpringDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SdmSpringDemoApplication.class, args);
	}

}
