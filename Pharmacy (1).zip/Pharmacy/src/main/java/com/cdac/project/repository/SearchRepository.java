package com.cdac.project.repository;

import org.springframework.data.repository.CrudRepository;

public interface SearchRepository{

}
