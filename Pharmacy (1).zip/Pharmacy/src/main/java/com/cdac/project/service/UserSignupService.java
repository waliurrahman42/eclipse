package com.cdac.project.service;

import com.cdac.project.model.UserSignup;

public interface UserSignupService {
	UserSignup saveUser(UserSignup user);
}
